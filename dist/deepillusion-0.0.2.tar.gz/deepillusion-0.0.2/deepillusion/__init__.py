"""Adversarial Machine Learning ToolBox

- Currently includes Pytorch implementations
- Tensorflow and Jax will follow
"""

from ._version import __version__

__all__ = ["__version__"]
