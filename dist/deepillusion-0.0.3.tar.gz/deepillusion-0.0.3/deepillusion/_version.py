__all__ = ["__version__"]

# major, minor, patch, -extra
version_info = 0, 0, 3

__version__ = '.'.join(map(str, version_info))
